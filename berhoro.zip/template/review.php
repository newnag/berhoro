<div class="review-page">
    <div class="head-text">
        <h1>รีวิว ทั้งหมด</h1>
    </div>

    <div class="gallery">
        <div class="column">
            <!-- column1 -->
            <figure><img src="img/review7.jpg" alt=""></figure>
            <figure><img src="img/test1.jpg" alt=""></figure>
            <figure><img src="img/test3.jpg" alt=""></figure>
            <figure><img src="img/review3.jpg" alt=""></figure>
            <figure><img src="img/review2.jpg" alt=""></figure>
            <figure><img src="img/test1.jpg" alt=""></figure>
            <figure><img src="img/review1.jpg" alt=""></figure>
            <figure><img src="img/review5.jpg" alt=""></figure>

            <!-- column2 -->
            <figure><img src="img/review5.jpg" alt=""></figure>
            <figure><img src="img/test3.jpg" alt=""></figure>
            <figure><img src="img/review1.jpg" alt=""></figure>
            <figure><img src="img/review2.jpg" alt=""></figure>
            <figure><img src="img/test1.jpg" alt=""></figure>
            <figure><img src="img/test5.jpg" alt=""></figure>
            <figure><img src="img/review1.jpg" alt=""></figure>
            <figure><img src="img/review5.jpg" alt=""></figure>

            <!-- column3 -->
            <figure><img src="img/test4.jpg" alt=""></figure>
            <figure><img src="img/review1.jpg" alt=""></figure>
            <figure><img src="img/test1.jpg" alt=""></figure>
            <figure><img src="img/review2.jpg" alt=""></figure>
            <figure><img src="img/review2.jpg" alt=""></figure>
            <figure><img src="img/test1.jpg" alt=""></figure>
            <figure><img src="img/review5.jpg" alt=""></figure>
            <figure><img src="img/test2.jpg" alt=""></figure>

        </div>
    </div>

    <div class="show-review">
        <div class="box-show">
            <figure><img src="" alt=""></figure>
            <div class="close-button"><i class="fas fa-times-circle"></i></div>
        </div>
    </div>
</div>