<div class="article-content">
    <div class="head-text">
        <h1>บทความ</h1>
    </div>

    <!-- กล่องบทความ -->
    <div class="box-article">
        <div class="item">
            <figure><img src="img/review3.jpg" alt=""></figure>
            <div class="head">
                <a href="article-detail"><h2>Now Available ON STREAM - KATAkana Kami : A WAY OF THE SAMURAI Strory, 10% OFF!</h2></a>
                <div class="author"><span>BiaBooster</span></div>
                <div class="share"><span>แบ่งปัน : <i class="fab fa-facebook-f"></i></span></div>
            </div>
            <div class="date"><span>19 พย.</span></div>
        </div>

        <div class="item">
            <figure><img src="img/review3.jpg" alt=""></figure>
            <div class="head">
                <a href="article-detail"><h2>Now Available ON STREAM - KATAkana Kami : A WAY OF THE SAMURAI Strory, 10% OFF!</h2></a>
                <div class="author"><span>BiaBooster</span></div>
                <div class="share"><span>แบ่งปัน : <i class="fab fa-facebook-f"></i></span></div>
            </div>
            <div class="date"><span>19 พย.</span></div>
        </div>

        <div class="item">
            <figure><img src="img/review3.jpg" alt=""></figure>
            <div class="head">
                <a href="article-detail"><h2>Now Available ON STREAM - KATAkana Kami : A WAY OF THE SAMURAI Strory, 10% OFF!</h2></a>
                <div class="author"><span>BiaBooster</span></div>
                <div class="share"><span>แบ่งปัน : <i class="fab fa-facebook-f"></i></span></div>
            </div>
            <div class="date"><span>19 พย.</span></div>
        </div>

        <div class="item">
            <figure><img src="img/review3.jpg" alt=""></figure>
            <div class="head">
                <a href="article-detail"><h2>Now Available ON STREAM - KATAkana Kami : A WAY OF THE SAMURAI Strory, 10% OFF!</h2></a>
                <div class="author"><span>BiaBooster</span></div>
                <div class="share"><span>แบ่งปัน : <i class="fab fa-facebook-f"></i></span></div>
            </div>
            <div class="date"><span>19 พย.</span></div>
        </div>

        <div class="item">
            <figure><img src="img/review3.jpg" alt=""></figure>
            <div class="head">
                <a href="article-detail"><h2>Now Available ON STREAM - KATAkana Kami : A WAY OF THE SAMURAI Strory, 10% OFF!</h2></a>
                <div class="author"><span>BiaBooster</span></div>
                <div class="share"><span>แบ่งปัน : <i class="fab fa-facebook-f"></i></span></div>
            </div>
            <div class="date"><span>19 พย.</span></div>
        </div>
    </div>
</div>