<footer class="container" style="margin-bottom: 2%">
    <div class="logo">
        <figure><img src="img/logo/logo.png" alt=""></figure>
        <a href="">http://www.berhoro.com</a>
    </div>

    <div class="certificate">
        <figure><img src="img/logo/Artboard – 28.jpg" alt=""></figure>
        <figure><img src="img/logo/Artboard – 29.jpg" alt=""></figure>
    </div>

    <div class="contact-footer">
        <h3>ติดต่อเรา</h3>
        <p class="address">
            99/444 กาญจนาภิเษก แขวงคันนายาว เขตขันนายาว กรุงเทพมหานคร 10230
        </p>
        <p class="phone">Phone: 063289555</p>
        <p class="line">Line ID: @berhoro</p>
    </div>

    <div class="service">
        <h3>บริการ</h3>
        <ul>
            <li><a href="">ทำนายเบอร์</a></li>
            <li><a href="">วิธีการสั่งซื้อเบอร์</a></li>
            <li><a href="">แจ้งชำระเงิน</a></li>
            <li><a href="">เช็คการจัดส่ง</a></li>
            <li><a href="">บทความ</a></li>
        </ul>
    </div>

    <div class="other-text">
        <h3>Lorem Ipsum is simply dummy</h3>
        <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
        <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
    </div>
</footer>

<div class="copy-right">
    <p>&copy; copyright 2020 by <a href="https://www.wynnsoft-solution.com/">wynnsoft-solution.com</a></p>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="plugin/owl.carousel.js"></script>
<script src="js/slider.js?v=<?=date('his'); ?>"></script>
<script src="js/app.js?v=<?=date('his'); ?>"></script>