<div class="last-releast-content">
    <div class="head-releast">
        <div class="head-text">
            <h1>จัดส่งสินค้าล่าสุด</h1>
        </div>
        <!-- ช่องค้นหา -->
        <div class="input-search">
            <input type="text" maxlength="32" placeholder="ค้นหาชื่อ หรือ เบอร์โทร">
            <i class="fas fa-search"></i>
        </div>
    </div>

    <!-- ข้อมูลEMS -->
    <div class="table">
        <div class="head-table">
            <div class="name"><h3>ชื่อ</h3></div>
            <div class="no-ems"><h3>เลขที่จัดส่ง</h3></div>
            <div class="ber"><h3>หมายเลขสินค้า</h3></div>
        </div>

        <div class="data-table">
            <div class="name"><span>Rem</span></div>
            <div class="no-ems"><span>E85E20LIN216FEQED</span></div>
            <div class="ber">
                <span>XXX20985602</span>
            </div>
        </div>

        <div class="data-table">
            <div class="name"><span>Rem</span></div>
            <div class="no-ems"><span>E85E20LIN216FEQED</span></div>
            <div class="ber">
                <span>XXX20985602</span>
                <span>XXX20985602</span>
                <span>XXX20985602</span>
            </div>
        </div>

        <div class="data-table">
            <div class="name"><span>Rem</span></div>
            <div class="no-ems"><span>E85E20LIN216FEQED</span></div>
            <div class="ber">
                <span>XXX20985602</span>
                <span>XXX20985602</span>
            </div>
        </div>

        <div class="data-table">
            <div class="name"><span>Rem</span></div>
            <div class="no-ems"><span>E85E20LIN216FEQED</span></div>
            <div class="ber">
                <span>XXX20985602</span>
            </div>
        </div>

        <div class="data-table">
            <div class="name"><span>Rem</span></div>
            <div class="no-ems"><span>E85E20LIN216FEQED</span></div>
            <div class="ber">
                <span>XXX20985602</span>
                <span>XXX20985602</span>
                <span>XXX20985602</span>
                <span>XXX20985602</span>
            </div>
        </div>

        <div class="data-table">
            <div class="name"><span>Rem</span></div>
            <div class="no-ems"><span>E85E20LIN216FEQED</span></div>
            <div class="ber">
                <span>XXX20985602</span>
                <span>XXX20985602</span>
                <span>XXX20985602</span>
                <span>XXX20985602</span>
            </div>
        </div>

        <div class="data-table">
            <div class="name"><span>Rem</span></div>
            <div class="no-ems"><span>E85E20LIN216FEQED</span></div>
            <div class="ber">
                <span>XXX20985602</span>
            </div>
        </div>

        <div class="data-table">
            <div class="name"><span>Rem</span></div>
            <div class="no-ems"><span>E85E20LIN216FEQED</span></div>
            <div class="ber">
                <span>XXX20985602</span>
            </div>
        </div>

        <div class="data-table">
            <div class="name"><span>Rem</span></div>
            <div class="no-ems"><span>E85E20LIN216FEQED</span></div>
            <div class="ber">
                <span>XXX20985602</span>
            </div>
        </div>
    </div>

    <div class="pagination">
        <a href="" class="current">First Page</a>
        <a href="" class="current"><</a>
        <a href="" class="current">1</a>
        <a href="">2</a>
        <a href="">3</a>
        <a href="">4</a>
        <a href="">5</a>
        <a href="">6</a>
        <a href="">7</a>
        <a href="">8</a>
        <a href="">9</a>
        <a href="">10</a>
        <a href="">11</a>
        <a href="">12</a>
        <a href="">...</a>
        <a href="">40</a>
        <a href="">></a>
        <a href="">Last Page</a>
    </div>
</div>