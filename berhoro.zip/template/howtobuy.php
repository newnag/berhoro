<div class="howtobuy">
    <div class="head-text">
        <h1>วิธีสั่งซื้อ</h1>
    </div>

    <!-- ธนาคาร -->
    <div class="payby">
        <div class="paybybank">
            <h3>ชำระผ่านการโอน</h3>
            <div class="box-bank">
                <div class="item">
                    <figure><img src="img/bank/1-01.jpg" alt=""></figure>
                    <div class="text">
                        <span>บัญชี : ธนาคารกสิกรไทย</span>
                        <span>เลขบัญชี : 7732280256</span>
                        <span>ชื่อบัญชี : บริษัท พีดีเอส พรอสเพอริที จำกัด</span>
                    </div>
                </div>

                <div class="item">
                    <figure><img src="img/bank/2-01.jpg" alt=""></figure>
                    <div class="text">
                        <span>บัญชี : ธนาคารกสิกรไทย</span>
                        <span>เลขบัญชี : 7732280256</span>
                        <span>ชื่อบัญชี : บริษัท พีดีเอส พรอสเพอริที จำกัด</span>
                    </div>
                </div>

                <div class="item">
                    <figure><img src="img/bank/3-01.jpg" alt=""></figure>
                    <div class="text">
                        <span>บัญชี : ธนาคารกสิกรไทย</span>
                        <span>เลขบัญชี : 7732280256</span>
                        <span>ชื่อบัญชี : บริษัท พีดีเอส พรอสเพอริที จำกัด</span>
                    </div>
                </div>

                <div class="item">
                    <figure><img src="img/bank/4-01.jpg" alt=""></figure>
                    <div class="text">
                        <span>บัญชี : ธนาคารกสิกรไทย</span>
                        <span>เลขบัญชี : 7732280256</span>
                        <span>ชื่อบัญชี : บริษัท พีดีเอส พรอสเพอริที จำกัด</span>
                    </div>
                </div>

                <div class="item">
                    <figure><img src="img/bank/5-01.jpg" alt=""></figure>
                    <div class="text">
                        <span>บัญชี : ธนาคารกสิกรไทย</span>
                        <span>เลขบัญชี : 7732280256</span>
                        <span>ชื่อบัญชี : บริษัท พีดีเอส พรอสเพอริที จำกัด</span>
                    </div>
                </div>

                <div class="item">
                    <figure><img src="img/bank/6-01.jpg" alt=""></figure>
                    <div class="text">
                        <span>บัญชี : ธนาคารกสิกรไทย</span>
                        <span>เลขบัญชี : 7732280256</span>
                        <span>ชื่อบัญชี : บริษัท พีดีเอส พรอสเพอริที จำกัด</span>
                    </div>
                </div>

                <div class="item">
                    <figure><img src="img/bank/7-01.jpg" alt=""></figure>
                    <div class="text">
                        <span>บัญชี : ธนาคารกสิกรไทย</span>
                        <span>เลขบัญชี : 7732280256</span>
                        <span>ชื่อบัญชี : บริษัท พีดีเอส พรอสเพอริที จำกัด</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="paybycredit">
            <h3>ชำระผ่านบัตรเครดิต</h3>
            <div class="box-credit">
                <figure><img src="img/bank/Master-card.jpg" alt=""></figure>
                <figure><img src="img/bank/american-express.jpg" alt=""></figure>
                <figure><img src="img/bank/union-pay.jpg" alt=""></figure>
                <figure><img src="img/bank/visa.jpg" alt=""></figure>
                <figure><img src="img/bank/JCB-01.jpg" alt=""></figure>
            </div>
        </div>
    </div>

    <!-- เนื้อหาck -->
    <div class="ck">
        <p>
            เนื้อหาคอนเทนท์ CK เนื้อหาคอนเทนท์ CK เนื้อหาคอนเทนท์ CK เนื้อหาคอนเทนท์ CK เนื้อหาคอนเทนท์ CK เนื้อหาคอนเทนท์ CK
            เนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CKvเนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CK
            เนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CK
            เนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CK
            เนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CK
            เนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CK เนื้อหาคอนเทนท์ CK เนื้อหาคอนเทนท์ CK
            เนื้อหาคอนเทนท์ CK เนื้อหาคอนเทนท์ CK เนื้อหาคอนเทนท์ CK เนื้อหาคอนเทนท์ CK เนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CK เนื้อหาคอนเทนท์ CK
            เนื้อหาคอนเทนท์ CK เนื้อหาคอนเทนท์ CK เนื้อหาคอนเทนท์ CK เนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CK เนื้อหาคอนเทนท์ CK
            เนื้อหาคอนเทนท์ CK เนื้อหาคอนเทนท์ CK เนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CK เนื้อหาคอนเทนท์ CK เนื้อหาคอนเทนท์ CKเนื้อหาคอนเทนท์ CK
            
        </p>
    </div>
</div>